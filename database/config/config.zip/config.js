module.exports = {
    USER: 'sendpack@sendpack.com.ar', 
    PASS: 'Sendpack!2020',

    clienteMail: 'davicoaz@gmail.com'
}